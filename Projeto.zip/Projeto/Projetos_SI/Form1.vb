﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub AdivinharNúmerosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdivinharNúmerosToolStripMenuItem.Click
        Try
            Process.Start(Application.StartupPath & "\Batch\jogosorteio.bat")
        Catch ex As Exception

        End Try
    End Sub
End Class
