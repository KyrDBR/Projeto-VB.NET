create database login_adsma2;
use login_adsma2;
drop table if exists tb_login;
create table tb_login (
	id_conta int identity (1,1) not null primary key,
	usuario varchar(20) not null,
	senha varchar(20) not null,
	status varchar(20) not null
);

insert into tb_login values('robertinho', '1234', 'bloqueada'),
							('testador', 'chupeta', 'ativa');
select * from tb_login;
update tb_login 
set status='bloqueada' where id_conta=1;



