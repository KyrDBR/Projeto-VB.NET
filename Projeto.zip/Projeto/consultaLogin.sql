
insert into tb_login values('robertinho', '1234'),
							('testador', 'chupeta');
select * from tb_login;

delete from tb_login;

