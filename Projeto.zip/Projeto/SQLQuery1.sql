create database cad_clientes_adsma2;
use cad_clientes_adsma2;
create table tb_clientes (
id_cliente int identity (1,1) not null primary key,
cpf varchar(14),
nome varchar(60),
data_nasc varchar(10),
fone varchar(22),
email varchar(60),
foto varchar(255));

select * from tb_clientes