use cad_clientes_adsma2;

select * from tb_clientes;